#include "mcc_generated_files/system/system.h"

uint8_t screenMem[1024];

void oled_write_cmd(uint8_t comms){
    A0_SetLow();
    CSB_SetLow();
    SPI0_ByteExchange(comms);
    CSB_SetHigh();
}

void oled_write_data(uint8_t comms){
    A0_SetHigh();
    CSB_SetLow();
    SPI0_ByteExchange(comms);
    CSB_SetHigh();
}

void INIT_MD1106G(){
    oled_write_cmd(0xB0);
    oled_write_cmd(0x10);
    oled_write_cmd(0x00);
    
    oled_write_cmd(0xA4);
    
    oled_write_cmd(0xD5);
    oled_write_cmd(0x50);
    
    oled_write_cmd(0xA8);
    oled_write_cmd(0x3F);
    
    oled_write_cmd(0xD3);
    oled_write_cmd(0x00);
    
    oled_write_cmd(0x40);
    
    oled_write_cmd(0xAD);
    oled_write_cmd(0x8B);
    
    oled_write_cmd(0x31);
    
    oled_write_cmd(0xA1);
    
    oled_write_cmd(0xc0);
    
    oled_write_cmd(0xDa);
    oled_write_cmd(0x12);
    
    oled_write_cmd(0x81);
    oled_write_cmd(0xff);
    
    oled_write_cmd(0xD9);
    oled_write_cmd(0x11);
    
    oled_write_cmd(0xDB);
    oled_write_cmd(0x35);
    
    oled_write_cmd(0xA6);
    
    oled_write_cmd(0xAF);
}

void clr_screen(){
    for (uint8_t pCount=0; pCount<8; pCount++){
        oled_write_cmd(0xb0 | pCount);
        oled_write_cmd(0x10);
        oled_write_cmd(0x02);
        for (int i=0; i<132; i++){
            oled_write_data(0xff);
        }
    }
    
    for (int i=0; i<1024; i++){
        screenMem[i]=0xff;
    }
}

void set_pixel(int row,int col){
    uint8_t mask = (1<<(row&7));
    uint16_t byteIdx = (128*(row>>3)) +col;
    screenMem[byteIdx] &= ~mask;
    col+=2;
    oled_write_cmd(0x10|(col>>4));
    oled_write_cmd(0x00|(col & 0xf));
    oled_write_cmd(0xb0|(row/8));
    
    oled_write_data(screenMem[byteIdx]);
}

int main(void)
{
    
    int colPos =64;
    int rowPos = 32;
    SYSTEM_Initialize();
    
    CSB_SetPullUp();
    screenCLR_SetPullUp();
    directionA_SetPullUp();
    directionB_SetPullUp();
    directionC_SetPullUp();
    directionD_SetPullUp();
    directionE_SetPullUp(); 

    //Set screen interface mode to 4-Wire SPI
    IM0_SetLow();
    IM1_SetLow();
    IM2_SetLow();
    CSB_SetHigh();
    
    RESB_SetLow();
    DELAY_milliseconds(100);
    RESB_SetHigh();

    INIT_MD1106G();
    clr_screen();
    
    while(1){
        if (screenCLR_GetValue()==0){
            clr_screen();
        } else if (directionA_GetValue()==0){
            if (rowPos>0){
                rowPos-=1;
            }
            DELAY_milliseconds(250);
        } else if (directionB_GetValue()==0){
            if (rowPos<63){
                rowPos+=1;
            }
            DELAY_milliseconds(250);
        } else if (directionD_GetValue()==0){
            if (colPos>0){
                colPos-=1;
            }
            DELAY_milliseconds(250);
        } else if (directionC_GetValue()==0){
            if (colPos<127){
                colPos+=1;
            }
            DELAY_milliseconds(250);
        } 
        else if (directionE_GetValue()== 0){
            rowPos=32;
            colPos=64;
        }
        
        set_pixel (rowPos,colPos);  
    }
}