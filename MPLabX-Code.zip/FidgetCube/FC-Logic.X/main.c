#include "mcc_generated_files/system/system.h"

#define _XTAL_FREQ (24000000)

void disCounter(int countVal)
{
    //Display count on Binary Counter
    int countTemp=0;
    //bin5
    countTemp = countVal/32;
    if (countTemp == 1){
        bin5_SetHigh();
        countVal=countVal-32;
    } else {
        bin5_SetLow();
    }
    //bin4
    countTemp = countVal/16;
    if (countTemp == 1){
        bin4_SetHigh();
        countVal=countVal-16;
    } else {
        bin4_SetLow();
    }
    //bin3
    countTemp = countVal/8;
    if (countTemp == 1){
        bin3_SetHigh();
        countVal=countVal-8;
    } else {
        bin3_SetLow();
    }
    //bin2
    countTemp = countVal/4;
    if (countTemp == 1){
        bin2_SetHigh();
        countVal=countVal-4;
    } else {
        bin2_SetLow();
    }
    //bin1
    countTemp = countVal/2;
    if (countTemp == 1){
        bin1_SetHigh();
        countVal=countVal-2;
    } else {
        bin1_SetLow();
    }
    //bin0
    if (countVal == 1){
        bin0_SetHigh();
    } else {
        bin0_SetLow();
    }
}

int main(void)
{
    SYSTEM_Initialize();
    int aState = 0;
    int bState = 0;
    int countBin =0;
    while(1){
        
        if (aIn_GetValue() == 0){
            if (aState == 0){
                aState = 1;
                aOn_SetHigh();
                DELAY_milliseconds(200);
            } else {
                aState = 0;
                aOn_SetLow();
                DELAY_milliseconds(200);
            }            
        }
        
        if (bIn_GetValue() == 0){
            if (bState == 0){
                bState = 1;
                bOn_SetHigh();
                DELAY_milliseconds(200);
            } else {
                bState = 0;
                bOn_SetLow();
                DELAY_milliseconds(200);
            }            
        }
        
        //AND and NAND
        if ((bState ==1) & (aState ==1)){
            and_SetHigh();
            nand_SetLow();
        } else {
            and_SetLow();
            nand_SetHigh();
        }
        
        //OR and NOR
        if ((bState ==1) | (aState ==1)){
            or_SetHigh();
            nor_SetLow();
            //XOR and XNOR
            if ((bState ==1) & (aState ==1)){
                xor_SetLow();
                xnor_SetHigh();
            }else {
                xor_SetHigh();
                xnor_SetLow();
            }
        } else {
            or_SetLow();
            nor_SetHigh();
        }
        
        if (countUp_GetValue() == 0){
            //add 1 to binary counter
            if (countBin<63){
                countBin++;
            } else {
                //countBin =0;
            }
            disCounter(countBin);           
            DELAY_milliseconds(200);            
        }
        
        if (countDown_GetValue() == 0){
            //take 1 from binary counter
            if (countBin>0){
                countBin--;
            }
            disCounter(countBin);
            DELAY_milliseconds(200);
        }
    }
}